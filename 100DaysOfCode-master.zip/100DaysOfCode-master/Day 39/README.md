# #100DaysOfCode Challenge
## Day 39: Quick Overview
Solved 4 problems from HackerRank - Problem Solving
1. [MinimumDistances.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2039/MinimumDistances.py)
2. [BeautifulTriplets.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2039/BeautifulTriplets.py)
3. [OrganizingContainersOfBalls.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2039/OrganizingContainersOfBalls.py)
4. [TaumAndBDay.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2039/TaumAndBDay.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms