# #100DaysOfCode Challenge
## Day 1: Quick Overview
Solved two problems from HackerEarth Codemonk Series<br>
1. [Monk and Rotation](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2001/MonkandRotation.py)
2. [Monk and Inversions](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2001/MonkandInversions.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/
