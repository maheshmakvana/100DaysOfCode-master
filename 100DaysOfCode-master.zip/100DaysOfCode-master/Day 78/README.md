# #100DaysOfCode Challenge
## Day 78: Quick Overview
Solved 2 problems from HackerEarth - Algorithms
1. [HelpNatsu.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2078/HelpNatsu.py)
2. [SamsHeight.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2078/SamsHeight.py)
### 
Read more about HackerEarth - Algorithms here : https://www.hackerearth.com/practice/algorithms