# #100DaysOfCode Challenge
## Day 92: Quick Overview
Solved 1 problems from HackerRank - Algorithms
1. [BearAndSteadyGene.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2092/BearAndSteadyGene.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms