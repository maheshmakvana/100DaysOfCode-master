# #100DaysOfCode Challenge
## Day 45: Quick Overview
Solved 3 problems from HackerRank -  Problem Solving
1. [StrongPassword.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2045/StrongPassword.py)
2. [CamelCase.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2045/CamelCase.py)
3. [TwoCharacters.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2045/TwoCharacters.py)
### 
Read more about HackerRank -  Problem Solving here : https://www.hackerrank.com/domains/algorithms