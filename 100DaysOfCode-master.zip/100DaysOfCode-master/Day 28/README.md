# #100DaysOfCode Challenge
## Day 28: Quick Overview
Solved 4 problems from HackerRank - Problem Solving
1. [UtopianTree.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2028/UtopianTree.py)
2. [JumpingOnTheClouds.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2028/JumpingOnTheClouds.py)
3. [AngryProfessor.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2028/AngryProfessor.py)
4. [FindDigits.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2028/FindDigits.py)

Read more about HackerEarth - Problem Solving here : https://www.hackerrank.com/domains/algorithms