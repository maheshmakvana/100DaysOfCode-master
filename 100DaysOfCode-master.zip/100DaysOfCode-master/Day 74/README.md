# #100DaysOfCode Challenge
## Day 74: Quick Overview
Solved 2 problems from HackerEarth - Data Structures
1. [SortItOut.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2074/SortItOut.py)
2. [EasyGoing.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2074/EasyGoing.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures