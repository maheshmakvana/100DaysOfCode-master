# #100DaysOfCode Challenge
## Day 53: Quick Overview
Solved 2 problems from HackerEarth Codemonk Series
1. [HelpJarvis.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2053/HelpJarvis.py)
2. [StrangeGame.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2053/StrangeGame.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/