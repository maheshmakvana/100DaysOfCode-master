'''

Tony Stark is in the planet Titan crying for his friends are turning into ashes, and on earth mayhem has ensued since a lot of people are turning into ashes too. Some trains have been derailed in such a way that a lot of its coaches are thrown off in a random disarray like coach 3, 4 and 5 are thrown off in one place, coach 2 and 6 are thrown off in another place, etc.
S.H.I.E.L.D calls upon Hulk and jarvis to help them collect and connect some the thrown off coaches of those trains, but a train can only move if the collected coaches number are in a continuous manner (need not to be in order) ,like 1234, 2314, 4123, 2341  etc.
Help Jarvis write a program for hulk to decide whether collected coaches will move or not.

Input Format:
First ilne contains one number t , denoting the number of test cases.
Next t lines contain sequence of the collected coach numbers (n)

Output Format:
YES or NO (In capitals)

Input constraints:
1 <= t <= 10000
1<= n <= 1000000

SAMPLE INPUT 
6
2415
4231
4125
5142
4132
2143

SAMPLE OUTPUT 
NO
YES
NO
NO
YES
YES


'''


for i in range(int(input())):
    a=[]
    coach_num=input()
    count=0
    for i in coach_num:
        a.append(int(i))
    a=sorted(a)
    b=str(a[0])
    for i in a:
        if(b in coach_num):
            b=str(int(b)+1)
            count+=1
    print ("YES" if(count==len(a)) else "NO")
