# #100DaysOfCode Challenge
## Day 79: Quick Overview
Solved 2 problems from HackerEarth - Algorithms
1. [MissingNumber.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2079/MissingNumber.py)
2. [FindingPairs.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2079/FindingPairs.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures