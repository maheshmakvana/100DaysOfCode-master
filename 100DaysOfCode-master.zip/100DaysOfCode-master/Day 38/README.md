# #100DaysOfCode Challenge
## Day 38: Quick Overview
Solved 3 problems from HackerRank - Problem Solving
1. [ACMICPCTeams.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2038/ACMICPCTeams.py)
2. [NonDivisibleSubset.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2038/NonDivisibleSubset.py)
3. [CutTheSticks.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2038/CutTheSticks.py)

Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms
