# #100DaysOfCode Challenge
## Day 19: Quick Overview
Solved 4 problems from HackerRank - Interview Preparation kit
1. [SherlockAndValidString.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2019/SherlockAndValidString.py)
2. [MakingAnagrams.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2019/MakingAnagrams.py)
3. [SpecialStringAgain.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2019/SpecialStringAgain.py)
4. [AlternatingCharacters.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2019/AlternatingCharacters.py)
### 
Read more about HackerRank - Interview Preparation kit here : https://www.hackerrank.com/interview/interview-preparation-kit