# #100DaysOfCode Challenge
## Day 33: Quick Overview
Solved 4 problems from HackerEarth - Basic Programming
1. [BirthdayParty.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2033/BirthdayParty.py)
2. [LetUsUnderstandComputer.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2033/LetUsUnderstandComputer.py)
3. [GoingToOffice.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2033/GoingToOffice.py)
5. [YetAnotherPartition.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2033/YetAnotherPartition.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/