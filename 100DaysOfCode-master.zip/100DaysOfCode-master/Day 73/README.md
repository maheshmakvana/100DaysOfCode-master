# #100DaysOfCode Challenge
## Day 73: Quick Overview
Solved 1 problems from HackerEarth - Data Structures
2. [MonksEncounterWithPolynomial.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2073/MonksEncounterWithPolynomial.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures