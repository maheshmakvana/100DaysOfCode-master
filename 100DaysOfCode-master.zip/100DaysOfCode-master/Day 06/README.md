# #100DaysOfCode Challenge
## Day 6: Quick Overview
Solved 2 Problems from HackerEarth Codemonk Series - Data Structures<br>
1. [Bracket Sequence](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2006/BracketSequences.py)
2. [Micro and Array Update ](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2006/MicroandArrayUpdate.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


