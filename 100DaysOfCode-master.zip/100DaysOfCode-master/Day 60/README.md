# #100DaysOfCode Challenge
## Day 60: Quick Overview
Solved 1 problems from HackerRank - Problem Solving
1. [TheBomberMan.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2060/TheBomberMan.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms