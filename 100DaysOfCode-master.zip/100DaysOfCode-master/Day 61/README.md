# #100DaysOfCode Challenge
## Day 61: Quick Overview
Solved 2 problems from HackerRank - Problem Solving
1. [FindTheMedian.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2061/FindTheMedian.py)
2. [ClosestNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2061/ClosestNumbers.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms