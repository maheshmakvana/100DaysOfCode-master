# #100DaysOfCode Challenge
## Day 32: Quick Overview
Solved 5 problems from HackerEarth - Basic Programming
1. [DeckOfCards.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2032/DeckOfCards.py)
2. [BobAndBombs.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2032/BobAndBombs.py)
4. [OddDivisors.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2032/OddDivisors.py)
5. [ShreyaAndNonPalindrome.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2032/ShreyaAndNonPalindrome.py)
6. [FinalDestination.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2032/FinalDestination.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/