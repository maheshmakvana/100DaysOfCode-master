# #100DaysOfCode Challenge
## Day 42: Quick Overview
Solved 2 problems from HackerRank - Problem solving
1. [ManasaAndStones.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2042/ManasaAndStones.py)
2. [TheGridSearch.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2042/TheGridSearch.py)
### 
Read more about HackerRank - Problem solving here : https://www.hackerrank.com/domains/algorithms/