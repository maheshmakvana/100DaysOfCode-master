# #100DaysOfCode Challenge
## Day 71: Quick Overview
Solved 2 problems from HackerEarth - Data Structures
1. [RestInPeace.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2071/RestInPeace.py)
2. [CountingFrogPaths.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2071/CountingFrogPaths.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures