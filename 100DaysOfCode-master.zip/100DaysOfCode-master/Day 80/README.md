# #100DaysOfCode Challenge
## Day 80: Quick Overview
Solved 3 problems from HackerEarth - Algorithms
1. [Capicua.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2080/Capicua.py)
2. [AliceAndStrings.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2080/AliceAndStrings.py)
3. [DNAPride.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2080/DNAPride.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures