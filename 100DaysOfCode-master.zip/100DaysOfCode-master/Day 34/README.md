# #100DaysOfCode Challenge
## Day 34: Quick Overview
Solved 4 problems from HackerEarth - Basic Programming
1. [ShubhamAndBinaryStrings.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2034/ShubhamAndBinaryStrings.py)
3. [Mystery.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2034/Mystery.py)
4. [CyclicShifts.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2034/CyclicShifts.py)
5. [DeterminingNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2034/DeterminingNumbers.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/