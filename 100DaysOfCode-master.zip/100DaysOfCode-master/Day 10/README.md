# #100DaysOfCode Challenge
## Day 10: Quick Overview
Solved 6 Problems from HackerEarth Codemonk Series - Basic Programming<br>
1. [A Movement](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/AMovement.py)
2. [Arthemetic Progression](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/ArithmeticProgression.py)
3. [Back to school](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/BackToSchool.py)
4. [Cipher](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/Cipher.py)
5. [Database](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/Database.py)
6. [Two Strings](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/TwoStrings.py)


Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


