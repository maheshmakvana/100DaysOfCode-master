# #100DaysOfCode Challenge
## Day 57: Quick Overview
Solved 2 problems from HackerRank - Problem Solving 
1. [MarsExploration.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2057/MarsExploration.py)
2. [CaesarCipher.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2057/CaesarCipher.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms