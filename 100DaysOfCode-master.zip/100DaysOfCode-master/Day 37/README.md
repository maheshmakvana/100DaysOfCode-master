# #100DaysOfCode Challenge
## Day 37: Quick Overview
Solved 3 problems from HackerRank - Interview Preparation kit
1. [MaxArraySum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2037/MaxArraySum.py)
2. [MinMaxRiddle.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2037/MinMaxRiddle.py)
3. [LinkedListInsertNodeAtSpecificPosition.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2037/LinkedListInsertNodeAtSpecificPosition.py)
### 
Read more aboutHackerRank - Interview Preparation kit here : https://www.hackerrank.com/interview/interview-preparation-kit