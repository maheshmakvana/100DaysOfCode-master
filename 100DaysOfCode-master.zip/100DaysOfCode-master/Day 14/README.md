# #100DaysOfCode Challenge
## Day 14: Quick Overview
Solved 8 problems from HackerEarth Codemonk Series
1. [VowelRecognition.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/VowelRecognition.py)
2. [CityTravel.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/CityTravel.py)
3. [RainSound.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/RainSound.py)
4. [A+B.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/A+B.py)
6. [DigitProblem.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/DigitProblem.py)
7. [FittingCircles.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/FittingCircles.py)
8. [ArrayInsert.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/ArrayInsert.py)
9. [AntiPalindromeStrings.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2014/AntiPalindromeStrings.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/