# #100DaysOfCode Challenge
## Day 31: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [Pairs.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2031/Pairs.py)
2. [ReverseShuffleMerge.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2031/ReverseShuffleMerge.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit