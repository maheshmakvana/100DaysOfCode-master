# #100DaysOfCode Challenge
## Day 76: Quick Overview
Solved 2 problems from HackerEarth - Algorithms
1. [SavePatients.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2076/SavePatients.py)
2. [TheBestPlayer.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2076/TheBestPlayer.py)
### 
Read more about HackerEarth - Algorithms here : https://www.hackerearth.com/practice/algorithms