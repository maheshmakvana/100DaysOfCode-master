# #100DaysOfCode Challenge
## Day 84: Quick Overview
Solved 2 problems from HackerRank - Algorithms
1. [AbsolutePermutation.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2084/AbsolutePermutation.py)
2. [3DSurfaceArea.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2084/3DSurfaceArea.py)
### 
Read more about HackerRank -Algorithms here : https://www.hackerrank.com/domains/algorithms