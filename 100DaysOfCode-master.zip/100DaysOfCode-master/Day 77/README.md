# #100DaysOfCode Challenge
## Day 77: Quick Overview
Solved 1 problems from HackerEarth - Algorithms
1. [OldKeypadInForeignLanguage.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2077/OldKeypadInForeignLanguage.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures