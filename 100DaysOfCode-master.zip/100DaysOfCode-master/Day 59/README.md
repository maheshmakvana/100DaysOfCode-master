# #100DaysOfCode Challenge
## Day 59: Quick Overview
Solved 3 problems from HackerRank - Problem Solving 
1. [Gemstones.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2059/Gemstones.py)
2. [SeparateTheNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2059/SeparateTheNumbers.py)
3. [FunnyString.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2059/FunnyString.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms