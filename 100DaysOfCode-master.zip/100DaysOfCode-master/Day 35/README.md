# #100DaysOfCode Challenge
## Day 35: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [TripleSum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2035/TripleSum.py)
2. [MinimumTimeRequired.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2035/MinimumTimeRequired.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/domains/algorithms