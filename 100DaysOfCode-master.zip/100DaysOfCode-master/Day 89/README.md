# #100DaysOfCode Challenge
## Day 89: Quick Overview
Solved 2 problems from HackerRank - Algorithms
1. [IceCreamParlor.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2089/IceCreamParlor.py)
2. [MaximumPerimeterTraingle.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2089/MaximumPerimeterTraingle.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms