# #100DaysOfCode Challenge
## Day 48: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation
1. [DavisStaircase.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2048/DavisStaircase.py)
2. [nthFibonacci.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2048/nthFibonacci.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit