# #100DaysOfCode Challenge
## Day 36: Quick Overview
Solved 2 problems from HackerEarth - Basic Programming
1. [DiwaliCelebrations.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2036/DiwaliCelebrations.py)
3. [CaseConversion.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2036/CaseConversion.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/