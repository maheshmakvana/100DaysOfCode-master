'''

Print the numbers
Given N numbers in the input. Print these numbers in the same order as they come in input.

Input:
First line contains integer N - denoting total count of numbers that are to be printed.
Second line contains N space separated integers.

Output:
Print the numbers in input.

Constraints:
1 <= N <= 100

SAMPLE INPUT 
5
56 30 3 94 58 
SAMPLE OUTPUT 
56 30 3 94 58 
Explanation
Simply all integers are printed.

'''
N=int(input(''))
a=list(map(int,input().split()))
print(*a,sep=' ')