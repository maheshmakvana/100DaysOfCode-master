# #100DaysOfCode Challenge
## Day 12: Quick Overview
Solved 5 problems from HackerEarth - Basic Programming
1. [PrintTheNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2012/PrintTheNumbers.py)
2. [AliAndHelpingInnocentPeople.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2012/AliAndHelpingInnocentPeople.py)
4. [LifeTheUniverseAndEverything.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2012/LifeTheUniverseAndEverything.py)
5. [ItsMagic.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2012/ItsMagic.py)
6. [Divisibility.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2012/Divisibility.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/