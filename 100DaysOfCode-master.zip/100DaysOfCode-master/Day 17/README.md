# #100DaysOfCode Challenge
## Day 17: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit and solved 10 problems from HackerRank - 30 Days of Code.
1. [FrequencyQueries.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/FrequencyQueries.py)
2. [Inheritance.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Inheritance.py)
3. [Exceptions.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Exceptions.py)
4. [FraudulentActivityNotifications.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/FraudulentActivityNotifications.py)
5. [MoreExceptions.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/MoreExceptions.py)
6. [QueuesAndStacks.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/QueuesAndStacks.py)
8. [LinkedList.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/LinkedList.py)
9. [Sorting.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Sorting.py)
10. [Scope.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Scope.py)
11. [Interfaces.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Interfaces.py)
12. [AbstractClasses.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/AbstractClasses.py)
13. [Generics.java](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2017/Generics.java)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit