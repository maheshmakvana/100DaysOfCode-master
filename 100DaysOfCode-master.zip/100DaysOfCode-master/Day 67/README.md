# #100DaysOfCode Challenge
## Day 67: Quick Overview
Solved 2 problems from HackerEarth - Data Structures
1. [MinimumAddToMakeParenthesesValid.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2067/MinimumAddToMakeParenthesesValid.py)
2. [StackOperations.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2067/StackOperations.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures