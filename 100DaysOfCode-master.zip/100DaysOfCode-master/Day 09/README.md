# #100DaysOfCode Challenge
## Day 9: Quick Overview
Solved 7 Problems from HackerEarth Codemonk Series - Basic Programming<br>
1. [Play with Numbers](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/PlayWithNumbers.py)
2. [Bricks Game](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/BricksGame.py)
3. [Char Sum](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/CharSum.py)
4. [Duration](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/Duration.py)
5. [E-maze-in](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/EMazeIn.py)
6. [Lift Queries](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/LiftQueries.py)
7. [Seven Segment Display](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2009/SevenSegmentDisplay.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


