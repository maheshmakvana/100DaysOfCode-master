# #100DaysOfCode Challenge
## Day 3: Quick Overview
Solved 'The Unlucky 13' and 'MinimumANDxorOR' Problems from HackerEarth Codemonk Series<br>
1. [The Unlucky 13](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2003/TheUnlucky13.cpp)
2. [MinimumANDxorOR](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2003/MinimumANDxorOR.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


