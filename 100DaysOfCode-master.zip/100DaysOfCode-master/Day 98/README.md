# #100DaysOfCode Challenge
## Day 98: Quick Overview
Solved 1 problem from HackerRank - Algorithms
1. [ShortPalindrome.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2098/ShortPalindrome.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms