# #100DaysOfCode Challenge
## Day 52: Quick Overview
Solved 3 problems from HackerEarth - Data Structures
1. [HamiltonianAndLagrangian.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2052/HamiltonianAndLagrangian.py)
2. [PolygonPossibilty.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2052/PolygonPossibilty.py)
3. [NeutralisationOfCharges.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2052/NeutralisationOfCharges.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/