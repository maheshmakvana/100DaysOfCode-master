# #100DaysOfCode Challenge
## Day 24: Quick Overview
Solved 5 problems from HackerRank - Problem Solving
1. [BonAppetit.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2024/BonAppetit.py)
2. [DrawingBook.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2024/DrawingBook.py)
3. [ElectronicsShop.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2024/ElectronicsShop.py)
5. [DayOfProgrammer.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2024/DayOfProgrammer.py)
6. [MigratoryBirds.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2024/MigratoryBirds.py)
### 
Read more about HackerEarth - Problem Solving here : https://www.hackerrank.com/domains/algorithms