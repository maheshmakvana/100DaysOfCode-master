# #100DaysOfCode Challenge
## Day 95: Quick Overview
Solved 1 problems from HackerRank - Algorithms
1. [EvenTree.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2095/EvenTree.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms