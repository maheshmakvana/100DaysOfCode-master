# #100DaysOfCode Challenge
## Day 7: Quick Overview
Solved 7 Problems from HackerEarth Codemonk Series - Basic Programming<br>
1. [Anagrams](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/Anagrams.py)
2. [Cost of Balloons](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/CostofBalloons.py)
3. [Factorial](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/Factorial.py)
4. [Number of Steps](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/NumberofSteps.py)
5. [Roy and Profile Picture](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/RoyandProfilePicture.py)
6. [Seating Arrangement](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/SeatingArrangement.py)
7. [Split Houses](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2007/SplitHouses.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


