# #100DaysOfCode Challenge
## Day 81: Quick Overview
Solved 4 problems from HackerEarth - Algorithms
1. [PrintFirstOccurence.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2081/PrintFirstOccurence.py)
2. [RemoveDuplicates.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2081/RemoveDuplicates.py)
3. [Conversion.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2081/Conversion.py)
4. [UpUp.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2081/UpUp.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures