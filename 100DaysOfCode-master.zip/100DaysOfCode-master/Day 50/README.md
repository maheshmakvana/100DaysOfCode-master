# #100DaysOfCode Challenge
## Day 50: Quick Overview
Solved 1 problems from HackerRank - Interview Preparation Kit
1. [FindTheNearestClone.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2050/FindTheNearestClone.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit