# #100DaysOfCode Challenge
## Day 27: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [GreedyFlorist.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2027/GreedyFlorist.py)
2. [MaxMin.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2027/MaxMin.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit