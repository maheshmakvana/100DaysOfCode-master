# #100DaysOfCode Challenge
## Day 70: Quick Overview
Solved 3 problems from HackerEarth - Data Structures
1. [GoldenRectangles.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2070/GoldenRectangles.py)
2. [SquareTransaction.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2070/SquareTransaction.py)
3. [MinMax.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2070/MinMax.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures