# #100DaysOfCode Challenge
## Day 29: Quick Overview
Solved 5 problems from HackerEarth - Basic Programming
1. [NumberOfArrays.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2029/NumberOfArrays.py)
2. [StringGame.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2029/StringGame.py)
3. [Pyramid.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2029/Pyramid.py)
4. [NumbersInRange.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2029/NumbersInRange.py)
5. [StringSum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2029/StringSum.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/