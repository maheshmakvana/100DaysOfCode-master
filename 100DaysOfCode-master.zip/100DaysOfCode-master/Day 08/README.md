# #100DaysOfCode Challenge
## Day 8: Quick Overview
Solved 8 Problems from HackerEarth Codemonk Series - Basic Programming<br>
1. [Count Divisors](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/CountDivisors.py)
2. [Divisible](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/Divisible.py)
3. [Find Product](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/FindProduct.py)
4. [Magical Word](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/MagicalWord.py)
5. [Palindromic String](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/PalindromicString.py)
6. [Toggle String](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/ToggleString.py)
7. [VC Pairs](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/VCPairs.py)
8. [Zoos](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2008/Zoos.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


