# #100DaysOfCode Challenge
## Day 20: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [CommonChild.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2020/CommonChild.py)
2. [CountingInversions.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2020/CountingInversions.py)
### 
Read more about HackerRank - Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit