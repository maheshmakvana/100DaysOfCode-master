# #100DaysOfCode Challenge
## Day 90: Quick Overview
Solved 1 problems from HackerRank - Algorithms
1. [MaximumPalindromes.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2090/MaximumPalindromes.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms