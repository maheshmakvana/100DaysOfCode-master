# #100DaysOfCode Challenge
## Day 47: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [FriendCircleQueries.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2047/FriendCircleQueries.py)
2. [RoadsAndLibraries.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2047/RoadsAndLibraries.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit