# #100DaysOfCode Challenge
## Day 5: Quick Overview
Solved 1 Problem from HackerEarth Codemonk Series - Sorting<br>
1. [Monk and Sorting Algorithm](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2005/MonkandSortingAlgorithm.cpp)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


