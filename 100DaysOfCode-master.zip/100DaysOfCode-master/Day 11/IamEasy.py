'''
I am Easy

This is an easy problem. 
All you need to do is to print the first 10 multiples of the number given in input.

Input:
An integer N, whose first 10 multiples need to be printed.

Output:
First 10 multiples of number given in input
'''

n= int(input())
for i in range(1,11):
    print(n*i)
