# #100DaysOfCode Challenge
## Day 11: Quick Overview
Solved 5 Problems from HackerEarth Practice - Basic Programming<br>
1. [Aman and Mr.Sharma](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/AmanAndMrSharma.py)
2. [Doctor's Secret](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/DoctorsSecret.py)
3. [Goki and his breakup](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/GokiAndHisBreakup.py)
4. [I am Easy](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/IamEasy.py)
5. [Minimize Cost](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2010/MinimizeCost.py)


Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


