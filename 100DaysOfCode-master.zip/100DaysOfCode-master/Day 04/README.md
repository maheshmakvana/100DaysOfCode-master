# #100DaysOfCode Challenge
## Day 4: Quick Overview
Solved 3 Problems from HackerEarth Codemonk Series - Sorting<br>
1. [Monk and Nice Strings](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2004/MonkandNiceStrings.py)
2. [Monk and Suffix Sort](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2004/MonkandSuffixSort.py)
3. [Monk being monitor](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2004/MonkbeingMonitor.py)

Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/


