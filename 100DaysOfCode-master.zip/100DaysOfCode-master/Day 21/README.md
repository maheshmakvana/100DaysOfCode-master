# #100DaysOfCode Challenge
## Day 21: Quick Overview
Solved 2 problems from HackerRank - Interview Preparation Kit
1. [SwapNodes.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2021/SwapNodes.py)
2. [IceCreamParlor.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2021/IceCreamParlor.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit