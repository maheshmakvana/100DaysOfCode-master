'''
Hello

Kirti is new to programming and she doesn't know how to code. Can you write a code, which would print "Hello Kirti" on the screen.

SAMPLE INPUT 

SAMPLE OUTPUT 
Hello Kirti
'''
print ('Hello Kirti')