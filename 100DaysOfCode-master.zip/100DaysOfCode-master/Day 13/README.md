# #100DaysOfCode Challenge
## Day 13: Quick Overview
Solved 8 problems from HackerEarth Codemonk Series
1. [Hello.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/Hello.py)
2. [FriendsRelation.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/FriendsRelation.py)
3. [MinimumSteps.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/MinimumSteps.py)
4. [BestIndex.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/BestIndex.py)
6. [BookOfPotionMaking.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/BookOfPotionMaking.py)
7. [ConjectIt.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/ConjectIt.py)
8. [TeddyAndTweety.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/TeddyAndTweety.py)
9. [Ladderophilia.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2013/Ladderophilia.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/