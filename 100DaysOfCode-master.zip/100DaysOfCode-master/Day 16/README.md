# #100DaysOfCode Challenge
## Day 16: Quick Overview
Solved 6 problems from HackerEarth Codemonk Series
1. [ArraySum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/ArraySum.py)
2. [MagicalTree.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/MagicalTree.py)
3. [CountNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/CountNumbers.py)
5. [SetNumbers.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/SetNumbers.py)
6. [MinMax.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/MinMax.py)
7. [FindThePattern.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2016/FindThePattern.py)
### 
Read more about HackerEarth - Codemonk series here : https://www.hackerearth.com/practice/codemonk/