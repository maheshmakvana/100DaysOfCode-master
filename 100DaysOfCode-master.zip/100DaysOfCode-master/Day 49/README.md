# #100DaysOfCode Challenge
## Day 49: Quick Overview
Solved 1 problems from HackerRank - Interview Preparation Kit
1. [Abbreviation.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2049/Abbreviation.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit