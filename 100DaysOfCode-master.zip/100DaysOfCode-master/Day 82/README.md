# #100DaysOfCode Challenge
## Day 82: Quick Overview
Solved 3 problems from HackerEarth - Algorithms
1. [PrimeNumber.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2082/PrimeNumber.py)
2. [MoriartyAndTheCity.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2082/MoriartyAndTheCity.py)
3. [WhatIsYourMobileNumber.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2082/WhatIsYourMobileNumber.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures