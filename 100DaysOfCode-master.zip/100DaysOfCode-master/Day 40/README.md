# #100DaysOfCode Challenge
## Day 40: Quick Overview
Solved 3 problems from HackerRank - Problem solving
1. [ModifiedKarpekarNumber.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2040/ModifiedKarpekarNumber.py)
3. [ChoclateFeast.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2040/ChoclateFeast.py)
4. [HalloweenSale.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2040/HalloweenSale.py)
### 
Read more about HackerRank - Problem solving here : https://www.hackerrank.com/domains/algorithms