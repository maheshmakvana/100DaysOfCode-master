# #100DaysOfCode Challenge
## Day 30: Quick Overview
Solved 3 problems from HackerRank - Problem Solving
1. [AppendAndDelete.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2030/AppendAndDelete.py)
2. [LibraryFine.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2030/LibraryFine.py)
3. [SherlockAndSquares.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2030/SherlockAndSquares.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms