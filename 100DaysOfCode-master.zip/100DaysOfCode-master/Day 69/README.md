# #100DaysOfCode Challenge
## Day 69: Quick Overview
Solved 3 problems from HackerEarth - Data Structures
1. [MaximumSum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2069/MaximumSum.py)
2. [BreakupApp.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2069/BreakupApp.py)
3. [SimpleSearch.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2069/SimpleSearch.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures