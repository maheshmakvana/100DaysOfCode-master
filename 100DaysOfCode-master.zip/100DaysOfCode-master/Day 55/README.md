# #100DaysOfCode Challenge
## Day 55: Quick Overview
Solved 2 problems from HackerRank - Problem Solving
1. [ReducedString.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2055/ReducedString.py)
2. [HappyLadybugs.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2055/HappyLadybugs.py)
### 
Read more about HackerRank -  Problem Solving here : https://www.hackerrank.com/domains/algorithms