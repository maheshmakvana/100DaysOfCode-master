# #100DaysOfCode Challenge
## Day 51: Quick Overview
Solved 1 problems from HackerRank - Interview Preparation Kit
1. [MaximumSubArraySum.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2051/MaximumSubArraySum.py)
### 
Read more about HackerRank - Interview Preparation Kit here : https://www.hackerrank.com/interview/interview-preparation-kit