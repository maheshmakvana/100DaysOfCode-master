# #100DaysOfCode Challenge
## Day 64: Quick Overview
Solved 2 problems from HackerEarth - Data Structures
1. [LongATMQueue.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2064/LongATMQueue.py)
2. [MaximizeTheEarning.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2064/MaximizeTheEarning.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures