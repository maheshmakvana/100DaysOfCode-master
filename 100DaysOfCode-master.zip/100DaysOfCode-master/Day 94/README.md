# #100DaysOfCode Challenge
## Day 94: Quick Overview
Solved 1 problems from HackerRank - Algorithms
1. [ExtraLongFactorials.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2094/ExtraLongFactorials.py)
### 
Read more about HackerRank - Data Structures here : https://www.hackerrank.com/domains/algorithms