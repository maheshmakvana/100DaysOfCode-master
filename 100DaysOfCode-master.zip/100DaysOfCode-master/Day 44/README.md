# #100DaysOfCode Challenge
## Day 44: Quick Overviewww
Solved 2 problems from HackerRank -  Problem Solving
1. [FlippingBits.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2044/FlippingBits.py)
2. [Primality.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2044/Primality.py)
### 
Read more about HackerRank -  Problem Solving here : https://www.hackerrank.com/domains/algorithms