# #100DaysOfCode Challenge
## Day 96: Quick Overview
Solved 3 problems from HackerRank - Algorithms
1. [PriyankaAndToys.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2096/PriyankaAndToys.py)
2. [SherlockAndTheBeast.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2096/SherlockAndTheBeast.py)
3. [MarcsCakewalk.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2096/MarcsCakewalk.py)
### 
Read more about HackerRank - Algorithms here : https://www.hackerrank.com/domains/algorithms