# #100DaysOfCode Challenge
## Day 58: Quick Overview
Solved 3 problems from HackerRank - Problem Solving 
1. [Pangrams.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2058/Pangrams.py)
2. [HackerRankInAString.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2058/HackerRankInAString.py)
3. [WeightedUniformStrings.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2058/WeightedUniformStrings.py)
### 
Read more about HackerRank - Problem Solving here : https://www.hackerrank.com/domains/algorithms