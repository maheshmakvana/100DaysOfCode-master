# #100DaysOfCode Challenge
## Day 75: Quick Overview
Solved 2 problems from HackerEarth - Algorithms
1. [ShubhamAndXOR.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2075/ShubhamAndXOR.py)
2. [BubbleSort.py](https://github.com/sandeep-krishna/100DaysOfCode/blob/master/Day%2075/BubbleSort.py)
### 
Read more about HackerEarth - Data Structures here : https://www.hackerearth.com/practice/data-structures